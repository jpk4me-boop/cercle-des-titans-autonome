import{c as a}from"./index-ZaLCxQEm.js";const e=a("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]),o=a("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{e as C,o as a};
